
import { useState, useCallback } from 'react';
import { generatePixelArt } from '../services/geminiService';

export const usePixelArtGenerator = () => {
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const generateImage = useCallback(async (prompt: string) => {
        if (!prompt.trim()) {
            setError("Prompt cannot be empty.");
            return;
        }

        setIsLoading(true);
        setError(null);
        setImageUrl(null);

        try {
            const url = await generatePixelArt(prompt);
            setImageUrl(url);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : "An unknown error occurred.";
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    }, []);

    return { imageUrl, isLoading, error, generateImage };
};
