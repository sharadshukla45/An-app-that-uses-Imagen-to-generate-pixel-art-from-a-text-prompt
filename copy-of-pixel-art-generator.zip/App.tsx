
import React from 'react';
import Header from './components/Header';
import PromptInput from './components/PromptInput';
import PixelArtDisplay from './components/PixelArtDisplay';
import { usePixelArtGenerator } from './hooks/usePixelArtGenerator';

const App: React.FC = () => {
    const { imageUrl, isLoading, error, generateImage } = usePixelArtGenerator();

    return (
        <div className="min-h-screen bg-slate-900 text-white flex flex-col p-4">
            <main className="container mx-auto max-w-4xl flex-grow">
                <Header />
                <div className="mt-8">
                    <PromptInput onSubmit={generateImage} isLoading={isLoading} />
                </div>
                <PixelArtDisplay
                    imageUrl={imageUrl}
                    isLoading={isLoading}
                    error={error}
                />
            </main>
            <footer className="text-center p-4 text-slate-500 text-sm">
                <p>Powered by Google Imagen 3. © {new Date().getFullYear()} Pixel Art Generator.</p>
            </footer>
        </div>
    );
};

export default App;
