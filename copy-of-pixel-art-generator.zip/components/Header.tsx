
import React from 'react';
import { PixelHeartIcon } from './icons/PixelHeartIcon';

const Header: React.FC = () => {
    return (
        <header className="text-center p-6 text-slate-200">
            <div className="flex items-center justify-center gap-4 mb-2">
                <PixelHeartIcon className="w-10 h-10 text-red-500" />
                <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-pink-500">
                    Pixel Art Generator
                </h1>
                <PixelHeartIcon className="w-10 h-10 text-red-500" />
            </div>
            <p className="text-slate-400">
                Craft retro-style masterpieces from your words with Imagen.
            </p>
        </header>
    );
};

export default Header;
