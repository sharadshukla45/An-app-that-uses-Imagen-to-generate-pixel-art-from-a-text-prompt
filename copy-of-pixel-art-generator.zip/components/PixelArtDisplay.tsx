
import React from 'react';
import LoadingSpinner from './LoadingSpinner';
import ErrorDisplay from './ErrorDisplay';

interface PixelArtDisplayProps {
    imageUrl: string | null;
    isLoading: boolean;
    error: string | null;
}

const DownloadIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
);


const PixelArtDisplay: React.FC<PixelArtDisplayProps> = ({ imageUrl, isLoading, error }) => {
    
    const DisplayContent: React.FC = () => {
        if (isLoading) {
            return <LoadingSpinner />;
        }
        if (error) {
            return <ErrorDisplay message={error} />;
        }
        if (imageUrl) {
            return (
                <div className="flex flex-col items-center gap-6">
                    <div className="bg-slate-800 p-2 border-4 border-slate-700 rounded-lg shadow-lg shadow-cyan-500/10">
                         <img
                            src={imageUrl}
                            alt="Generated pixel art"
                            className="w-full max-w-md h-auto object-contain rounded pixelated"
                         />
                    </div>
                    <a
                        href={imageUrl}
                        download="pixel-art.png"
                        className="inline-flex items-center gap-2 px-6 py-2 bg-pink-500 text-white font-bold rounded-lg hover:bg-pink-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-pink-500 transition duration-200"
                    >
                        <DownloadIcon className="w-5 h-5" />
                        Download
                    </a>
                </div>
            );
        }
        return (
             <div className="text-center text-slate-500">
                <p className="text-xl">Your generated pixel art will appear here.</p>
                <p>Enter a prompt above and click generate!</p>
            </div>
        );
    };

    return (
        <div className="w-full max-w-2xl mx-auto my-8 p-8 bg-slate-900/50 border-2 border-dashed border-slate-700 rounded-2xl min-h-[400px] flex items-center justify-center transition-all duration-300">
            <DisplayContent />
        </div>
    );
};

export default PixelArtDisplay;
