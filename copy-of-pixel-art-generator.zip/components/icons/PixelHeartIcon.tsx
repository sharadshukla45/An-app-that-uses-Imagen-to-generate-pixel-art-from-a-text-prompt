
import React from 'react';

export const PixelHeartIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 13 12" 
        fill="currentColor"
        className={className}
        style={{ imageRendering: 'pixelated' }}
    >
        <path d="M0 3H1V2H2V1H3V0H4V1H5V2H6V3H7V2H8V1H9V0H10V1H11V2H12V3H13V4H12V5H11V6H10V7H9V8H8V9H7V10H6V11H5V12H4V11H3V10H2V9H1V8H0V7H1V6H2V5H3V4H4V3H3V4H2V5H1V6H0V5H1V4H0V3Z" />
    </svg>
);
