
import { GoogleGenAI } from "@google/genai";

// Ensure the environment variable is handled outside this code.
const apiKey = process.env.API_KEY;
if (!apiKey) {
    // This provides a clear error for developers if the API key is missing.
    // In a production environment, this check might be handled differently.
    console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || '' });

export const generatePixelArt = async (prompt: string): Promise<string> => {
    if (!apiKey) {
        throw new Error("API key is not configured. Please set the API_KEY environment variable.");
    }
    
    try {
        // Enhance the prompt for better pixel art results
        const enhancedPrompt = `pixel art of ${prompt}, 8-bit, retro video game style, vibrant colors`;

        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: enhancedPrompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/png',
                aspectRatio: '1:1',
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0 && response.generatedImages[0].image.imageBytes) {
            const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
            return `data:image/png;base64,${base64ImageBytes}`;
        } else {
            throw new Error("Image generation failed: No image data received from API.");
        }
    } catch (error) {
        console.error("Error generating pixel art:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to generate image: ${error.message}`);
        }
        throw new Error("An unknown error occurred during image generation.");
    }
};
